

exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda amplify/backend/function/storagefunction/src/index.js!'),
    };
    return response;
};
